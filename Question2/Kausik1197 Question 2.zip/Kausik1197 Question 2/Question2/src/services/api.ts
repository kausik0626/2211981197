
import { User, Post, Comment } from '../types';

// Helper function to generate a random image URL
const getRandomImage = (width = 400, height = 400, seed?: number): string => {
  const seedValue = seed ? seed : Math.floor(Math.random() * 1000);
  return `https://picsum.photos/seed/${seedValue}/${width}/${height}`;
};

// Generate random users
const generateUsers = (count: number): User[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    username: `user${i + 1}`,
    name: `User ${i + 1}`,
    avatar: getRandomImage(100, 100, i + 1),
    postCount: Math.floor(Math.random() * 20) + 1
  }));
};

// Generate random comments for a post
const generateComments = (postId: number, users: User[], count: number): Comment[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: postId * 100 + i + 1,
    userId: users[Math.floor(Math.random() * users.length)].id,
    user: users[Math.floor(Math.random() * users.length)],
    postId,
    content: `This is comment ${i + 1} on post ${postId}. Lorem ipsum dolor sit amet, consectetur adipiscing elit.`,
    timestamp: new Date(Date.now() - Math.floor(Math.random() * 10000000)).toISOString()
  }));
};

// Generate random posts
const generatePosts = (users: User[], count: number): Post[] => {
  return Array.from({ length: count }, (_, i) => {
    const userId = users[Math.floor(Math.random() * users.length)].id;
    const user = users.find(u => u.id === userId)!;
    const commentCount = Math.floor(Math.random() * 15) + 1;
    
    return {
      id: i + 1,
      userId,
      user,
      content: `This is post ${i + 1}. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.`,
      image: getRandomImage(800, 600, i + 100),
      timestamp: new Date(Date.now() - Math.floor(Math.random() * 86400000)).toISOString(),
      comments: generateComments(i + 1, users, commentCount),
      likes: Math.floor(Math.random() * 100)
    };
  });
};

// Initial mock data
const users = generateUsers(20);
let posts = generatePosts(users, 30);

// API Functions
export const getTopUsers = async (limit = 5): Promise<User[]> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Sort users by post count and return top 'limit'
  return [...users].sort((a, b) => b.postCount - a.postCount).slice(0, limit);
};

export const getTrendingPosts = async (): Promise<Post[]> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 700));
  
  // Find max comment count
  const maxCommentCount = Math.max(...posts.map(post => post.comments.length));
  
  // Return all posts with the max comment count
  return posts.filter(post => post.comments.length === maxCommentCount);
};

export const getFeed = async (page = 1, limit = 10): Promise<{ posts: Post[], hasMore: boolean }> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // Sort posts by timestamp (newest first)
  const sortedPosts = [...posts].sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
  
  // Paginate results
  const startIndex = (page - 1) * limit;
  const paginatedPosts = sortedPosts.slice(startIndex, startIndex + limit);
  
  return {
    posts: paginatedPosts,
    hasMore: startIndex + limit < sortedPosts.length
  };
};

export const addNewPost = async (content: string, userId: number): Promise<Post> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Find the user
  const user = users.find(u => u.id === userId)!;
  
  // Create new post
  const newPost: Post = {
    id: posts.length + 1,
    userId,
    user,
    content,
    image: getRandomImage(800, 600),
    timestamp: new Date().toISOString(),
    comments: [],
    likes: 0
  };
  
  // Update user's post count
  user.postCount += 1;
  
  // Add post to the list
  posts = [newPost, ...posts];
  
  return newPost;
};

export const getRandomPostImage = (): string => {
  return getRandomImage(800, 600);
};

export const getRandomUserAvatar = (): string => {
  return getRandomImage(100, 100);
};
