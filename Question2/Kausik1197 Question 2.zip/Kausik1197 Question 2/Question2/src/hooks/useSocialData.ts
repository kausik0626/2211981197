
import { useState, useEffect, useCallback } from 'react';
import { getTopUsers, getTrendingPosts, getFeed } from '@/services/api';
import { User, Post } from '@/types';

export const useTopUsers = (limit = 5) => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchTopUsers = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getTopUsers(limit);
      setUsers(data);
    } catch (err) {
      setError(err as Error);
      console.error('Error fetching top users:', err);
    } finally {
      setLoading(false);
    }
  }, [limit]);

  useEffect(() => {
    fetchTopUsers();
  }, [fetchTopUsers]);

  return { users, loading, error, refetch: fetchTopUsers };
};

export const useTrendingPosts = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchTrendingPosts = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getTrendingPosts();
      setPosts(data);
    } catch (err) {
      setError(err as Error);
      console.error('Error fetching trending posts:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTrendingPosts();
    
    // Set up polling for new trending posts every minute
    const interval = setInterval(fetchTrendingPosts, 60000);
    
    return () => clearInterval(interval);
  }, [fetchTrendingPosts]);

  return { posts, loading, error, refetch: fetchTrendingPosts };
};

export const useFeed = (initialPage = 1, pageSize = 10) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [page, setPage] = useState(initialPage);
  const [hasMore, setHasMore] = useState(true);

  const fetchFeed = useCallback(async (pageNum = initialPage, refresh = false) => {
    try {
      if (pageNum === initialPage) {
        setLoading(true);
      } else {
        setLoadingMore(true);
      }
      setError(null);
      
      const response = await getFeed(pageNum, pageSize);
      
      if (refresh || pageNum === initialPage) {
        setPosts(response.posts);
      } else {
        setPosts(prevPosts => [...prevPosts, ...response.posts]);
      }
      
      setHasMore(response.hasMore);
      setPage(pageNum);
    } catch (err) {
      setError(err as Error);
      console.error('Error fetching feed:', err);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [initialPage, pageSize]);

  useEffect(() => {
    fetchFeed();
    
    // Set up polling for new posts every 30 seconds
    const interval = setInterval(() => {
      fetchFeed(initialPage, true);
    }, 30000);
    
    return () => clearInterval(interval);
  }, [fetchFeed, initialPage]);

  const loadMore = () => {
    if (!loadingMore && hasMore) {
      fetchFeed(page + 1);
    }
  };

  const refresh = () => {
    fetchFeed(initialPage, true);
  };

  return { 
    posts, 
    loading, 
    loadingMore, 
    error, 
    hasMore, 
    loadMore, 
    refresh 
  };
};
