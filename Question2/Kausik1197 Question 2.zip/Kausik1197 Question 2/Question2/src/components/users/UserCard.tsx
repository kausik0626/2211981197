
import React from 'react';
import { User } from '@/types';
import { FilePenLine } from 'lucide-react';
import { cn } from '@/lib/utils';

interface UserCardProps {
  user: User;
  rank: number;
}

const UserCard: React.FC<UserCardProps> = ({ user, rank }) => {
  return (
    <div className="flex items-center gap-4 p-4 rounded-lg border bg-card text-card-foreground shadow-sm transition-all hover:shadow-md">
      <div className={cn(
        "flex items-center justify-center w-8 h-8 rounded-full font-bold text-white",
        rank === 1 ? "bg-yellow-500" : 
        rank === 2 ? "bg-gray-400" : 
        rank === 3 ? "bg-amber-600" : 
        "bg-primary"
      )}>
        {rank}
      </div>
      <div className="relative">
        <img 
          src={user.avatar} 
          alt={user.name} 
          className="w-14 h-14 rounded-full object-cover border-2 border-background"
        />
        {rank <= 3 && (
          <div className={cn(
            "absolute -top-1 -right-1 w-6 h-6 flex items-center justify-center rounded-full text-xs font-bold text-white",
            rank === 1 ? "bg-yellow-500" : 
            rank === 2 ? "bg-gray-400" : 
            "bg-amber-600"
          )}>
            {rank === 1 ? "🏆" : rank === 2 ? "🥈" : "🥉"}
          </div>
        )}
      </div>
      <div className="flex-1">
        <h3 className="font-semibold">{user.name}</h3>
        <p className="text-sm text-muted-foreground">@{user.username}</p>
      </div>
      <div className="flex flex-col items-center justify-center">
        <div className="flex items-center gap-1.5">
          <FilePenLine className="w-4 h-4 text-primary" />
          <span className="font-semibold">{user.postCount}</span>
        </div>
        <p className="text-xs text-muted-foreground">posts</p>
      </div>
    </div>
  );
};

export default UserCard;
