
import React from 'react';
import StatsCard from '@/components/ui/StatsCard';
import { MessageSquare, Users, TrendingUp, BarChart3 } from 'lucide-react';

interface AnalyticsDashboardProps {
  totalUsers: number;
  totalPosts: number;
  totalComments: number;
  engagementRate: number;
}

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  totalUsers,
  totalPosts,
  totalComments,
  engagementRate,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <StatsCard
        title="Total Users"
        value={totalUsers}
        icon={Users}
        description="Active users on the platform"
        trend="up"
        trendValue="12%"
      />
      <StatsCard
        title="Total Posts"
        value={totalPosts}
        icon={BarChart3}
        description="Posts created on the platform"
        trend="up"
        trendValue="8%"
      />
      <StatsCard
        title="Total Comments"
        value={totalComments}
        icon={MessageSquare}
        description="Comments across all posts"
        trend="up"
        trendValue="24%"
      />
      <StatsCard
        title="Engagement Rate"
        value={`${engagementRate}%`}
        icon={TrendingUp}
        description="Average engagement per post"
        trend="up"
        trendValue="5%"
      />
    </div>
  );
};

export default AnalyticsDashboard;
