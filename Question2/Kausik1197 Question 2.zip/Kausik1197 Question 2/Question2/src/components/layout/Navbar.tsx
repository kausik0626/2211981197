
import { Link, useLocation } from 'react-router-dom';
import { BarChart3, Users, TrendingUp, Home } from 'lucide-react';
import { cn } from '@/lib/utils';

const Navbar = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  return (
    <header className="sticky top-0 z-30 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-16 items-center px-4 md:px-6">
        <Link to="/" className="flex items-center gap-2">
          <BarChart3 className="h-6 w-6 text-primary" />
          <span className="font-bold text-xl">SocialAnalytics</span>
        </Link>
        <nav className="ml-auto flex items-center gap-4 sm:gap-6">
          <Link 
            to="/" 
            className={cn(
              "flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary",
              isActive('/') ? "text-primary" : "text-muted-foreground"
            )}
          >
            <Home className="h-4 w-4" />
            <span className="hidden sm:inline">Feed</span>
          </Link>
          <Link 
            to="/top-users" 
            className={cn(
              "flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary",
              isActive('/top-users') ? "text-primary" : "text-muted-foreground"
            )}
          >
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Top Users</span>
          </Link>
          <Link 
            to="/trending" 
            className={cn(
              "flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary",
              isActive('/trending') ? "text-primary" : "text-muted-foreground"
            )}
          >
            <TrendingUp className="h-4 w-4" />
            <span className="hidden sm:inline">Trending</span>
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
