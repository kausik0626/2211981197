
import React from 'react';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  className?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  icon: Icon,
  description,
  trend,
  trendValue,
  className,
}) => {
  return (
    <div className={cn(
      "rounded-lg border bg-card text-card-foreground shadow-sm p-6",
      className
    )}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <div className="bg-primary/10 p-2 rounded-full">
          <Icon className="h-5 w-5 text-primary" />
        </div>
      </div>
      
      <div className="mt-3">
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </div>
      
      {trend && trendValue && (
        <div className="mt-4 pt-4 border-t flex items-center">
          <div
            className={cn(
              "text-xs font-medium inline-flex items-center rounded-full px-2 py-1",
              trend === 'up' && "text-green-700 bg-green-100",
              trend === 'down' && "text-red-700 bg-red-100",
              trend === 'neutral' && "text-gray-700 bg-gray-100"
            )}
          >
            {trend === 'up' && '↑'}
            {trend === 'down' && '↓'}
            {trend === 'neutral' && '•'}
            <span className="ml-1">{trendValue}</span>
          </div>
          <span className="text-xs text-muted-foreground ml-2">vs. last period</span>
        </div>
      )}
    </div>
  );
};

export default StatsCard;
