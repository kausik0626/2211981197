
import React, { useState } from 'react';
import { addNewPost, getRandomPostImage } from '@/services/api';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ImageIcon, SendIcon, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface NewPostFormProps {
  onPostCreated: () => void;
}

const NewPostForm: React.FC<NewPostFormProps> = ({ onPostCreated }) => {
  const [content, setContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const { toast } = useToast();

  const handleAddImage = () => {
    setPreviewImage(getRandomPostImage());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) {
      toast({
        title: "Empty post",
        description: "Please add some content to your post",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // In a real app, you'd get the actual user ID from auth context
      // For this demo we'll use a random user ID between 1-10
      const userId = Math.floor(Math.random() * 10) + 1;
      
      await addNewPost(content, userId);
      setContent('');
      setPreviewImage(null);
      onPostCreated();
      
      toast({
        title: "Post created",
        description: "Your post has been published successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mb-8 p-4 border rounded-lg bg-card">
      <h2 className="text-lg font-semibold mb-3">Create Post</h2>
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="What's on your mind?"
        className="min-h-[100px] mb-3"
        disabled={isLoading}
      />
      
      {previewImage && (
        <div className="mb-3 relative rounded-md overflow-hidden">
          <img src={previewImage} alt="Preview" className="w-full h-auto max-h-[200px] object-cover" />
          <button
            type="button"
            className="absolute top-2 right-2 bg-black/70 text-white p-1 rounded-full"
            onClick={() => setPreviewImage(null)}
          >
            ×
          </button>
        </div>
      )}
      
      <div className="flex justify-between">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleAddImage}
          disabled={isLoading || !!previewImage}
        >
          <ImageIcon className="h-4 w-4 mr-2" />
          Add Image
        </Button>
        
        <Button type="submit" disabled={isLoading || !content.trim()}>
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Posting...
            </>
          ) : (
            <>
              <SendIcon className="h-4 w-4 mr-2" />
              Post
            </>
          )}
        </Button>
      </div>
    </form>
  );
};

export default NewPostForm;
