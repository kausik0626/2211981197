
import React from 'react';
import { Post } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { MessageSquare, Heart, Share2 } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface PostCardProps {
  post: Post;
  isTrending?: boolean;
}

const PostCard: React.FC<PostCardProps> = ({ post, isTrending = false }) => {
  return (
    <div className={`rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden transition-all hover:shadow-md ${isTrending ? 'animate-pulse-gentle border-primary/50' : ''}`}>
      <div className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <img 
            src={post.user.avatar} 
            alt={post.user.name} 
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <h3 className="font-semibold">{post.user.name}</h3>
            <p className="text-sm text-muted-foreground">
              {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
            </p>
          </div>
        </div>
        <p className="mb-4">{post.content}</p>
        {post.image && (
          <div className="mb-4 rounded-md overflow-hidden">
            <img 
              src={post.image} 
              alt="Post" 
              className="w-full h-auto object-cover max-h-[400px]"
            />
          </div>
        )}
        <div className="flex items-center justify-between mt-2 pt-2 border-t">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{post.likes}</span>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger className="flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{post.comments.length}</span>
                </TooltipTrigger>
                <TooltipContent>
                  {post.comments.length} {post.comments.length === 1 ? 'comment' : 'comments'}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <Share2 className="w-4 h-4" />
            <span className="hidden sm:inline">Share</span>
          </button>
        </div>
        
        {isTrending && post.comments.length > 0 && (
          <div className="mt-4 pt-4 border-t">
            <h4 className="text-sm font-medium mb-3">Top comment</h4>
            <div className="bg-accent/50 p-3 rounded-md">
              <div className="flex items-center gap-2 mb-2">
                <img 
                  src={post.comments[0].user.avatar} 
                  alt={post.comments[0].user.name} 
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span className="text-sm font-medium">{post.comments[0].user.name}</span>
              </div>
              <p className="text-sm">{post.comments[0].content}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PostCard;
