
import React from 'react';
import { FileQuestion } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
}

const EmptyState: React.FC<EmptyStateProps> = ({ title, description }) => {
  return (
    <div className="text-center py-12 bg-accent/30 rounded-lg border border-accent animate-fade-in">
      <div className="flex justify-center mb-4">
        <div className="p-4 bg-accent rounded-full">
          <FileQuestion className="h-8 w-8 text-muted-foreground" />
        </div>
      </div>
      <h3 className="text-lg font-medium">{title}</h3>
      <p className="text-muted-foreground mt-2 max-w-sm mx-auto">{description}</p>
    </div>
  );
};

export default EmptyState;
