
import React from 'react';
import PageLayout from '@/components/layout/PageLayout';
import UserCard from '@/components/users/UserCard';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { useTopUsers } from '@/hooks/useSocialData';
import { Award, TrendingUp } from 'lucide-react';
import AnalyticsDashboard from '@/components/analytics/AnalyticsDashboard';
import EmptyState from '@/components/posts/EmptyState';
import { Skeleton } from '@/components/ui/skeleton';

const TopUsers = () => {
  const { users, loading } = useTopUsers(5);

  // Calculate some basic analytics
  const totalPosts = users.reduce((sum, user) => sum + user.postCount, 0);
  const avgPostsPerUser = users.length > 0 ? Math.round(totalPosts / users.length * 10) / 10 : 0;

  return (
    <PageLayout 
      title="Top Users" 
      description="Users with the highest number of posts"
    >
      <div className="max-w-3xl mx-auto">
        <AnalyticsDashboard
          totalUsers={20} // In a real app, this would come from an API
          totalPosts={totalPosts}
          totalComments={150} // In a real app, this would come from an API
          engagementRate={75} // In a real app, this would come from an API
        />

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-lg border bg-card">
                <Skeleton className="w-8 h-8 rounded-full" />
                <Skeleton className="w-14 h-14 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-16" />
                </div>
                <div className="flex flex-col items-center gap-1">
                  <Skeleton className="h-4 w-8" />
                  <Skeleton className="h-3 w-12" />
                </div>
              </div>
            ))}
          </div>
        ) : users.length === 0 ? (
          <EmptyState 
            title="No users available" 
            description="Check back later for top user data"
          />
        ) : (
          <>
            <div className="mb-8 bg-accent rounded-lg p-6 animate-scale-in">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-primary rounded-full">
                  <Award className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Top Contributors</h3>
                  <p className="text-sm text-muted-foreground">
                    Users with the most posts on our platform
                    <span className="ml-2 font-medium text-primary">
                      (avg: {avgPostsPerUser} posts/user)
                    </span>
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
                {users.slice(0, 3).map((user, index) => (
                  <div 
                    key={user.id} 
                    className="bg-card p-4 rounded-lg border text-center shadow-sm hover:shadow-md transition-all"
                  >
                    <div className="relative inline-block">
                      <img 
                        src={user.avatar} 
                        alt={user.name} 
                        className="w-20 h-20 rounded-full object-cover mx-auto border-4 border-background"
                      />
                      <div className={`absolute -top-2 -right-2 w-8 h-8 flex items-center justify-center rounded-full text-xs font-bold text-white ${
                        index === 0 ? "bg-yellow-500" : 
                        index === 1 ? "bg-gray-400" : 
                        "bg-amber-600"
                      }`}>
                        {index === 0 ? "🏆" : index === 1 ? "🥈" : "🥉"}
                      </div>
                    </div>
                    <h3 className="font-semibold mt-3">{user.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">@{user.username}</p>
                    <div className="flex items-center justify-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-primary" />
                      <span className="font-semibold">{user.postCount}</span>
                      <span className="text-xs text-muted-foreground">posts</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <h3 className="text-lg font-semibold mb-4">Leaderboard</h3>
            <div className="space-y-3 animate-fade-in">
              {users.map((user, index) => (
                <UserCard 
                  key={user.id} 
                  user={user} 
                  rank={index + 1} 
                />
              ))}
            </div>
          </>
        )}
      </div>
    </PageLayout>
  );
};

export default TopUsers;
