
import React from 'react';
import PageLayout from '@/components/layout/PageLayout';
import PostCard from '@/components/posts/PostCard';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import NewPostForm from '@/components/posts/NewPostForm';
import { useFeed } from '@/hooks/useSocialData';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';
import AnalyticsDashboard from '@/components/analytics/AnalyticsDashboard';
import { PostSkeletonList } from '@/components/posts/PostSkeleton';
import EmptyState from '@/components/posts/EmptyState';

const Feed = () => {
  const { 
    posts, 
    loading, 
    loadingMore, 
    hasMore, 
    loadMore, 
    refresh 
  } = useFeed();

  const handlePostCreated = () => {
    refresh();
  };
  
  // Calculate analytics for dashboard
  const totalPosts = posts.length;
  const uniqueUsers = new Set(posts.map(post => post.userId)).size;
  const totalComments = posts.reduce((sum, post) => sum + post.comments.length, 0);
  const engagementRate = totalPosts > 0 
    ? Math.round((totalComments / totalPosts) * 100) / 100
    : 0;

  return (
    <PageLayout 
      title="Feed" 
      description="See the latest posts from users in real-time"
    >
      <div className="max-w-3xl mx-auto">
        <AnalyticsDashboard
          totalUsers={20} // In a real app, this would come from an API
          totalPosts={30} // In a real app, this would come from an API
          totalComments={totalComments}
          engagementRate={engagementRate}
        />
      
        <NewPostForm onPostCreated={handlePostCreated} />
        
        <div className="mb-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold">Recent Posts</h2>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={refresh}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        {loading ? (
          <PostSkeletonList />
        ) : posts.length === 0 ? (
          <EmptyState 
            title="No posts available" 
            description="Be the first to create a post!"
          />
        ) : (
          <div className="space-y-6 animate-fade-in">
            {posts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
            
            {hasMore && (
              <div className="pt-2 pb-8 text-center">
                <Button
                  onClick={loadMore}
                  disabled={loadingMore}
                  variant="outline"
                >
                  {loadingMore ? (
                    <>
                      <LoadingSpinner size="sm" className="mr-2" />
                      Loading...
                    </>
                  ) : (
                    'Load More'
                  )}
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Feed;
