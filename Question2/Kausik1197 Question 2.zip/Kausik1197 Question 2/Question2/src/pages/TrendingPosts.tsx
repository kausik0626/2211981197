
import React from 'react';
import PageLayout from '@/components/layout/PageLayout';
import PostCard from '@/components/posts/PostCard';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import { useTrendingPosts } from '@/hooks/useSocialData';
import { TrendingUp, MessageSquare } from 'lucide-react';
import AnalyticsDashboard from '@/components/analytics/AnalyticsDashboard';
import { PostSkeletonList } from '@/components/posts/PostSkeleton';
import EmptyState from '@/components/posts/EmptyState';

const TrendingPosts = () => {
  const { posts, loading } = useTrendingPosts();

  // Calculate analytics for dashboard
  const totalComments = posts.reduce((sum, post) => sum + post.comments.length, 0);
  const avgCommentsPerPost = posts.length > 0 ? Math.round(totalComments / posts.length) : 0;

  return (
    <PageLayout 
      title="Trending Posts" 
      description="Posts with the highest number of comments"
    >
      <div className="max-w-3xl mx-auto">
        <AnalyticsDashboard
          totalUsers={20} // In a real app, this would come from an API
          totalPosts={30} // In a real app, this would come from an API
          totalComments={totalComments}
          engagementRate={avgCommentsPerPost}
        />

        <div className="mb-8 bg-accent rounded-lg p-6 animate-scale-in">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary rounded-full">
              <TrendingUp className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">What's Trending</h3>
              <p className="text-sm text-muted-foreground">Posts with the most engagement right now</p>
            </div>
          </div>
        </div>

        {loading ? (
          <PostSkeletonList />
        ) : posts.length === 0 ? (
          <EmptyState 
            title="No trending posts available" 
            description="Check back later for trending content"
          />
        ) : (
          <>
            {posts.length > 0 && (
              <div className="flex items-center gap-2 mb-4">
                <MessageSquare className="h-5 w-5 text-primary" />
                <h3 className="text-lg font-semibold">
                  {posts.length > 1 
                    ? `${posts.length} posts with ${posts[0].comments.length} comments each` 
                    : `Post with ${posts[0].comments.length} comments`}
                </h3>
              </div>
            )}
            
            <div className="space-y-8 animate-fade-in">
              {posts.map(post => (
                <PostCard key={post.id} post={post} isTrending={true} />
              ))}
            </div>
          </>
        )}
      </div>
    </PageLayout>
  );
};

export default TrendingPosts;
