
export interface User {
  id: number;
  username: string;
  name: string;
  avatar: string;
  postCount: number;
}

export interface Post {
  id: number;
  userId: number;
  user: User;
  content: string;
  image: string;
  timestamp: string;
  comments: Comment[];
  likes: number;
}

export interface Comment {
  id: number;
  userId: number;
  user: User;
  postId: number;
  content: string;
  timestamp: string;
}
