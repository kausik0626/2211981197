import express from 'express';
import axios from 'axios';

const app = express();
const PORT = 3000;

// Base URLs and endpoints
const BASE_URL = 'https://20.244.56.144/evaluttion-service';
let authToken = '';

// Middleware to set headers
app.use((req, res, next) => {
  res.setHeader('Content-Type', 'application/json');
  next();
});

// Helper function to fetch data with authorization
const fetchData = async (url: string) => {
  const response = await axios.get(url, {
    headers: { Authorization: `Bearer ${authToken}` },
  });
  return response.data;
};

// Registration and Authorization
const registerAndAuthorize = async () => {
  try {
    // Register
    await axios.post(`${BASE_URL}/register`, {
      name: 'YourServiceName',
      email: 'your-email@example.com',
    });

    // Authorize
    const authResponse = await axios.post(`${BASE_URL}/auth`, {
      email: 'your-email@example.com',
    });
    authToken = authResponse.data.token;
  } catch (error) {
    console.error('Error during registration/authorization:', error.message);
  }
};

// Top Users API
app.get('/users', async (req, res) => {
  try {
    const users = await fetchData(`${BASE_URL}/users`);
    const userCommentCounts: { [key: string]: number } = {};

    for (const user of users) {
      const posts = await fetchData(`${BASE_URL}/users/${user.id}/posts`);
      for (const post of posts) {
        const comments = await fetchData(`${BASE_URL}/posts/${post.id}/comments`);
        userCommentCounts[user.id] = (userCommentCounts[user.id] || 0) + comments.length;
      }
    }

    const topUsers = Object.entries(userCommentCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([userId]) => users.find((user: any) => user.id === parseInt(userId)));

    res.json(topUsers);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch top users' });
  }
});

// Top/Latest Posts API
app.get('/posts', async (req, res) => {
  const { type } = req.query;

  try {
    const users = await fetchData(`${BASE_URL}/users`);
    let allPosts: any[] = [];

    for (const user of users) {
      const posts = await fetchData(`${BASE_URL}/users/${user.id}/posts`);
      allPosts = allPosts.concat(posts);
    }

    if (type === 'popular') {
      for (const post of allPosts) {
        const comments = await fetchData(`${BASE_URL}/posts/${post.id}/comments`);
        post.commentCount = comments.length;
      }
      allPosts.sort((a, b) => b.commentCount - a.commentCount);
    } else if (type === 'latest') {
      allPosts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    res.json(allPosts.slice(0, 10)); // Return top 10 posts
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
});

// Start the server
app.listen(PORT, async () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  await registerAndAuthorize();
});