import React, { useEffect, useState } from 'react';

const App = () => {
  const [topUsers, setTopUsers] = useState([]);
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    // Fetch top users
    fetch('http://localhost:3001/users')
      .then((res) => res.json())
      .then((data) => setTopUsers(data))
      .catch((err) => console.error(err));

    // Fetch popular posts
    fetch('http://localhost:3001/posts?type=popular')
      .then((res) => res.json())
      .then((data) => setPosts(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div>
      <h1>Top Users</h1>
      <ul>
        {topUsers.map((user: any) => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>

      <h1>Popular Posts</h1>
      <ul>
        {posts.map((post: any) => (
          <li key={post.id}>{post.title}</li>
        ))}
      </ul>
    </div>
  );
};

export default App;