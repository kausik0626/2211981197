
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Code } from '@/components/ui/code';

const ApiDocsHeader = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="mb-8 bg-white rounded-lg shadow-sm p-4">
      <Collapsible
        open={isOpen}
        onOpenChange={setIsOpen}
        className="w-full"
      >
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Social Media Analytics API</h2>
          <CollapsibleTrigger asChild>
            <Button variant="outline">
              {isOpen ? 'Hide API Docs' : 'Show API Docs'}
            </Button>
          </CollapsibleTrigger>
        </div>
        
        <CollapsibleContent className="mt-4 space-y-4">
          <div className="border-b pb-4">
            <h3 className="text-lg font-medium mb-2">Top Users API</h3>
            <p className="mb-2 text-gray-600">
              Get top five users with the most commented posts.
            </p>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-green-100 text-green-800 rounded px-2 py-1 text-xs font-medium">GET</span>
              <code className="bg-gray-100 px-2 py-1 rounded">http://hostname/users</code>
            </div>
            <h4 className="font-medium mt-3 mb-1">Example Response:</h4>
            <Code>
{`{
  "users": [
    { "id": 1, "name": "John Doe", "commentCount": 42 },
    { "id": 10, "name": "Helen Moore", "commentCount": 36 },
    { "id": 5, "name": "Charlie Brown", "commentCount": 29 },
    { "id": 3, "name": "Alice Smith", "commentCount": 21 },
    { "id": 7, "name": "Edward Davis", "commentCount": 18 }
  ]
}`}
            </Code>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">Posts API</h3>
            <p className="mb-2 text-gray-600">
              Get popular posts or latest posts based on query parameter.
            </p>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-green-100 text-green-800 rounded px-2 py-1 text-xs font-medium">GET</span>
              <code className="bg-gray-100 px-2 py-1 rounded">http://hostname/posts?type=popular</code>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              <strong>Query Parameters:</strong><br />
              <code>type</code> - Accepted values: <code>popular</code> or <code>latest</code>
            </p>
            <h4 className="font-medium mt-3 mb-1">Example Response (popular):</h4>
            <Code>
{`{
  "posts": [
    { 
      "id": 246, 
      "userid": 1, 
      "content": "Post about trending topic",
      "commentCount": 53
    },
    { 
      "id": 161, 
      "userid": 5, 
      "content": "Another trending post",
      "commentCount": 53
    }
  ]
}`}
            </Code>
            
            <h4 className="font-medium mt-3 mb-1">Example Response (latest):</h4>
            <Code>
{`{
  "posts": [
    { 
      "id": 952, 
      "userid": 15, 
      "content": "Latest post content",
      "timestamp": 1679486432000,
      "commentCount": 3
    },
    { 
      "id": 953, 
      "userid": 7, 
      "content": "Another recent post",
      "timestamp": 1679486300000,
      "commentCount": 1
    },
    // ... 3 more posts
  ]
}`}
            </Code>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};

export default ApiDocsHeader;
