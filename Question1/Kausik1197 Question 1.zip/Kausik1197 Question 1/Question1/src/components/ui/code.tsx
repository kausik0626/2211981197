
import { cn } from "@/lib/utils";

interface CodeProps extends React.HTMLAttributes<HTMLPreElement> {
  children: React.ReactNode;
}

export function Code({ className, children, ...props }: CodeProps) {
  return (
    <pre
      className={cn(
        "bg-muted text-muted-foreground rounded-md p-4 overflow-auto text-sm font-mono",
        className
      )}
      {...props}
    >
      {children}
    </pre>
  );
}
