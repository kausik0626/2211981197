
import React, { useEffect, useState } from 'react';
import DataService from '../services/DataService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const TopUsers = () => {
  const [users, setUsers] = useState<Array<{id: number, name: string, commentCount: number}>>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTopUsers = async () => {
      try {
        setLoading(true);
        const topUsers = await DataService.getTopUsers();
        setUsers(topUsers);
        setError(null);
      } catch (err) {
        setError('Failed to load top users');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchTopUsers();
    
    // Refresh data periodically
    const intervalId = setInterval(fetchTopUsers, 30000); // Every 30 seconds
    
    return () => clearInterval(intervalId);
  }, []);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Top Users</CardTitle>
      </CardHeader>
      <CardContent>
        {loading && <p>Loading top users...</p>}
        
        {error && (
          <div className="bg-red-100 p-3 rounded text-red-700 mb-3">
            {error}
          </div>
        )}
        
        {!loading && !error && (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rank</TableHead>
                <TableHead>User ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead className="text-right">Comment Count</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user, index) => (
                <TableRow key={user.id}>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.name}</TableCell>
                  <TableCell className="text-right">{user.commentCount}</TableCell>
                </TableRow>
              ))}
              {users.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4">
                    No user data available
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default TopUsers;
