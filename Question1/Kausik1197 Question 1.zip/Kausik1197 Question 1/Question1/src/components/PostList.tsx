
import React, { useEffect, useState } from 'react';
import DataService, { Post } from '../services/DataService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const PostList = () => {
  const [popularPosts, setPopularPosts] = useState<Post[]>([]);
  const [latestPosts, setLatestPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('popular');

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoading(true);
        
        // Fetch both types of posts
        const [popular, latest] = await Promise.all([
          DataService.getPopularPosts(),
          DataService.getLatestPosts()
        ]);
        
        setPopularPosts(popular);
        setLatestPosts(latest);
        setError(null);
      } catch (err) {
        setError('Failed to load posts');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
    
    // Refresh data periodically
    const intervalId = setInterval(fetchPosts, 30000); // Every 30 seconds
    
    return () => clearInterval(intervalId);
  }, []);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Posts</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="popular" onValueChange={setActiveTab} value={activeTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="popular">Popular</TabsTrigger>
            <TabsTrigger value="latest">Latest</TabsTrigger>
          </TabsList>
          
          {loading && <p>Loading posts...</p>}
          
          {error && (
            <div className="bg-red-100 p-3 rounded text-red-700 mb-3">
              {error}
            </div>
          )}
          
          <TabsContent value="popular">
            {!loading && !error && (
              <div className="space-y-4">
                {popularPosts.map(post => (
                  <div key={post.id} className="border rounded-lg p-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">User ID: {post.userid}</span>
                      <span className="text-sm font-semibold text-blue-600">{post.commentCount} comments</span>
                    </div>
                    <p className="text-lg">{post.content}</p>
                  </div>
                ))}
                {popularPosts.length === 0 && (
                  <p className="text-center py-8 text-gray-500">No popular posts available</p>
                )}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="latest">
            {!loading && !error && (
              <div className="space-y-4">
                {latestPosts.map(post => (
                  <div key={post.id} className="border rounded-lg p-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-500">User ID: {post.userid}</span>
                      <span className="text-sm font-semibold text-blue-600">{post.commentCount} comments</span>
                    </div>
                    <p className="text-lg">{post.content}</p>
                  </div>
                ))}
                {latestPosts.length === 0 && (
                  <p className="text-center py-8 text-gray-500">No latest posts available</p>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default PostList;
