
import axios, { AxiosInstance, AxiosRequestConfig } from "axios";
import AuthService from "./AuthService";
import ApiThrottler from "./ApiThrottler";
import CacheService from "./CacheService";

const API_BASE_URL = "http://20.244.56.144/evaluation-service";

class ApiClient {
  private instance: AxiosInstance;
  
  constructor() {
    this.instance = axios.create({
      baseURL: API_BASE_URL,
      timeout: 10000,
    });
    
    // Add request interceptor to automatically add auth token
    this.instance.interceptors.request.use(
      async (config) => {
        try {
          const token = await AuthService.getToken();
          config.headers.Authorization = `Bearer ${token}`;
          return config;
        } catch (error) {
          console.error("Error setting auth token:", error);
          return Promise.reject(error);
        }
      },
      (error) => {
        return Promise.reject(error);
      }
    );
  }
  
  async get<T>(url: string, config?: AxiosRequestConfig, cacheTTL: number = 60000): Promise<T> {
    const cacheKey = `GET:${url}`;
    
    // Use cache if available and not expired
    return CacheService.getOrFetch<T>(
      cacheKey,
      () => this.makeGetRequest<T>(url, config),
      cacheTTL
    );
  }
  
  private async makeGetRequest<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
    // Throttle API request to reduce load on test server
    return ApiThrottler.throttle<T>(async () => {
      try {
        const response = await this.instance.get<T>(url, config);
        return response.data;
      } catch (error) {
        console.error(`GET request failed for ${url}:`, error);
        throw error;
      }
    });
  }
  
  async post<T>(url: string, data: any, config?: AxiosRequestConfig): Promise<T> {
    // Throttle API request to reduce load on test server
    return ApiThrottler.throttle<T>(async () => {
      try {
        const response = await this.instance.post<T>(url, data, config);
        return response.data;
      } catch (error) {
        console.error(`POST request failed for ${url}:`, error);
        throw error;
      }
    });
  }
}

export default new ApiClient();
