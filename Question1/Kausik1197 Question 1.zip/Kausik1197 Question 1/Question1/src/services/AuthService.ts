
import axios from "axios";

const API_BASE_URL = "http://20.244.56.144/evaluation-service";

// Credentials for authentication - these should be stored securely in a real application
// For this test, we're using the sample credentials provided
interface AuthCredentials {
  email: string;
  name: string;
  rollNo: string;
  accessCode: string;
  clientID: string;
  clientSecret: string;
}

interface AuthResponse {
  token_type: string;
  access_token: string;
  expires_in: number;
}

class AuthService {
  private token: string | null = null;
  private tokenExpiry: number | null = null;
  private credentials: AuthCredentials;
  
  constructor() {
    // Initialize with the provided credentials
    // In a real application, these would be stored securely and not hard-coded
    this.credentials = {
      email: "rankrishna@abc.edu",
      name: "ran krishna",
      rollNo: "aalbb",
      accessCode: "xgASNC",
      clientID: "d9cbb699-6a27-44a5-8d59-8b1befa816da", 
      clientSecret: "tVJaaaR85eXcRXEM"
    };
  }

  async getToken(): Promise<string> {
    // Return existing token if it's valid
    if (this.token && this.tokenExpiry && this.tokenExpiry > Date.now()) {
      return this.token;
    }

    try {
      const response = await axios.post<AuthResponse>(
        `${API_BASE_URL}/auth`,
        this.credentials
      );

      if (response.data && response.data.access_token) {
        this.token = response.data.access_token;
        
        // Set expiry time (converting to milliseconds and adding buffer)
        if (response.data.expires_in) {
          this.tokenExpiry = Date.now() + (response.data.expires_in * 1000) - 60000; // Expire 1 minute early as buffer
        }
        
        return this.token;
      }
      
      throw new Error("Failed to obtain auth token");
    } catch (error) {
      console.error("Authentication error:", error);
      throw new Error("Authentication failed");
    }
  }
}

export default new AuthService();
