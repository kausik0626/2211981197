
// Simple in-memory cache service to reduce API calls

type CacheEntry<T> = {
  data: T;
  timestamp: number;
};

class CacheService {
  private cache: Map<string, CacheEntry<any>> = new Map();
  
  // Default TTL is 1 minute
  private defaultTTL = 60000;

  /**
   * Get data from cache or fetch it using the provided function
   * @param key Cache key
   * @param fetchFn Function to call if cache is missing or expired
   * @param ttl Time to live in milliseconds (default: 1 minute)
   */
  async getOrFetch<T>(key: string, fetchFn: () => Promise<T>, ttl = this.defaultTTL): Promise<T> {
    const now = Date.now();
    const cachedEntry = this.cache.get(key);
    
    // Return cached value if it exists and is not expired
    if (cachedEntry && now - cachedEntry.timestamp < ttl) {
      return cachedEntry.data;
    }
    
    // Fetch fresh data
    const data = await fetchFn();
    
    // Update cache
    this.cache.set(key, {
      data,
      timestamp: now
    });
    
    return data;
  }
  
  /**
   * Store data in the cache
   * @param key Cache key
   * @param data Data to store
   */
  set<T>(key: string, data: T): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }
  
  /**
   * Clear the entire cache or a specific key
   * @param key Optional specific key to clear
   */
  clear(key?: string): void {
    if (key) {
      this.cache.delete(key);
    } else {
      this.cache.clear();
    }
  }
}

export default new CacheService();
