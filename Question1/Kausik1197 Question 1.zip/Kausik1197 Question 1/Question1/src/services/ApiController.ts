
import DataService from './DataService';

// This file represents how you would set up the API endpoints in a real backend service
// For this frontend demo, we're mocking them directly through our DataService

// In a real application, this would be a backend controller
// Since we're building a frontend demo, we're providing client-side functions:

export const getTopUsers = async () => {
  return await DataService.getTopUsers();
};

export const getPosts = async (type: 'popular' | 'latest') => {
  if (type === 'popular') {
    return await DataService.getPopularPosts();
  } else {
    return await DataService.getLatestPosts();
  }
};
