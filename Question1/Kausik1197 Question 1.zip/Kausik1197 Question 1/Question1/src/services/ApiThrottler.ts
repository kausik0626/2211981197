
/**
 * Service to handle API request throttling
 * This helps reduce the number of API calls to the test server
 */

type QueuedRequest<T> = {
  execute: () => Promise<T>;
  resolve: (value: T) => void;
  reject: (reason: any) => void;
};

class ApiThrottler {
  private queue: QueuedRequest<any>[] = [];
  private processing = false;
  private lastRequestTime = 0;
  
  // Minimum time between API requests (in milliseconds)
  private minInterval = 500; // 500ms between requests
  
  /**
   * Throttle an API request
   * @param fn Function that makes the API request
   * @returns Promise that resolves with the API response
   */
  async throttle<T>(fn: () => Promise<T>): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      // Add request to queue
      this.queue.push({
        execute: fn,
        resolve,
        reject
      });
      
      // Start processing queue if not already processing
      if (!this.processing) {
        this.processQueue();
      }
    });
  }
  
  private async processQueue(): Promise<void> {
    if (this.queue.length === 0) {
      this.processing = false;
      return;
    }
    
    this.processing = true;
    
    // Respect minimum interval between requests
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    
    if (timeSinceLastRequest < this.minInterval) {
      await new Promise(resolve => 
        setTimeout(resolve, this.minInterval - timeSinceLastRequest)
      );
    }
    
    // Process next request
    const request = this.queue.shift();
    if (!request) {
      this.processQueue();
      return;
    }
    
    try {
      this.lastRequestTime = Date.now();
      const result = await request.execute();
      request.resolve(result);
    } catch (error) {
      request.reject(error);
    }
    
    // Continue processing queue
    this.processQueue();
  }
}

export default new ApiThrottler();
