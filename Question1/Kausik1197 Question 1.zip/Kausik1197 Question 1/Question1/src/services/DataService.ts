import ApiClient from "./ApiClient";

// Types for API responses
export interface User {
  id: string;
  name: string;
}

export interface Post {
  id: number;
  userid: number;
  content: string;
  timestamp?: number; // We'll add this for sorting by latest
  commentCount?: number; // We'll populate this from comments data
}

export interface Comment {
  id: number;
  postid: number;
  content: string;
}

// Response types
interface UsersResponse {
  users: Record<string, string>; // { "1": "John Doe", ... }
}

interface PostsResponse {
  posts: Post[];
}

interface CommentsResponse {
  comments: Comment[];
}

// Main data service that handles caching and data retrieval
class DataService {
  private userCache: Map<string, User> = new Map();
  private postCache: Map<number, Post> = new Map();
  private commentCountByUser: Map<number, number> = new Map();
  private lastUsersFetch: number = 0;
  private lastDataRefresh: number = 0;
  private CACHE_TTL = 60000; // 1 minute cache TTL
  
  // Refresh interval to balance between freshness and API call costs
  private REFRESH_INTERVAL = 30000; // 30 seconds

  async refreshDataIfNeeded(): Promise<void> {
    const now = Date.now();
    
    // Only refresh if the cache is stale
    if (now - this.lastDataRefresh > this.REFRESH_INTERVAL) {
      await this.refreshAllData();
      this.lastDataRefresh = now;
    }
  }
  
  private async refreshAllData(): Promise<void> {
    try {
      // Step 1: Get all users
      const users = await this.getAllUsers();
      
      // Step 2: Get posts for each user (limit API calls)
      // To minimize API calls, we can be selective about which users we fetch
      // For this demo, we'll fetch for all users but in production you might want to be more selective
      for (const userId of Object.keys(users)) {
        await this.getPostsByUserId(userId);
      }
      
      // Step 3: For each post, get comments and update counts
      for (const post of this.postCache.values()) {
        await this.getCommentsByPostId(post.id);
      }
      
      // Step 4: Update comment counts by user
      this.updateCommentCountsByUser();
      
    } catch (error) {
      console.error("Error refreshing data:", error);
    }
  }
  
  private updateCommentCountsByUser(): void {
    // Reset the counter
    this.commentCountByUser.clear();
    
    // Count comments for each user based on their posts
    for (const post of this.postCache.values()) {
      const userId = post.userid;
      const commentCount = post.commentCount || 0;
      
      const currentCount = this.commentCountByUser.get(userId) || 0;
      this.commentCountByUser.set(userId, currentCount + commentCount);
    }
  }
  
  async getAllUsers(): Promise<Record<string, string>> {
    try {
      const now = Date.now();
      
      // Use cached data if it's fresh enough
      if (now - this.lastUsersFetch < this.CACHE_TTL && this.userCache.size > 0) {
        const userObj: Record<string, string> = {};
        this.userCache.forEach((user) => {
          userObj[user.id] = user.name;
        });
        return userObj;
      }
      
      const response = await ApiClient.get<UsersResponse>('/users');
      
      // Update cache
      for (const [id, name] of Object.entries(response.users)) {
        this.userCache.set(id, { id, name });
      }
      
      this.lastUsersFetch = now;
      return response.users;
    } catch (error) {
      console.error("Error fetching users:", error);
      throw error;
    }
  }
  
  async getPostsByUserId(userId: string): Promise<Post[]> {
    try {
      const response = await ApiClient.get<PostsResponse>(`/users/${userId}/posts`);
      
      // Update post cache with timestamp for "latest" sorting
      const now = Date.now();
      response.posts.forEach(post => {
        // If the post is not in cache, add a timestamp
        // If it already exists, keep the original timestamp
        const existingPost = this.postCache.get(post.id);
        if (!existingPost) {
          post.timestamp = now;
          post.commentCount = 0; // Initialize comment count
        } else {
          post.timestamp = existingPost.timestamp;
          post.commentCount = existingPost.commentCount;
        }
        this.postCache.set(post.id, post);
      });
      
      return response.posts;
    } catch (error) {
      console.error(`Error fetching posts for user ${userId}:`, error);
      throw error;
    }
  }
  
  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    try {
      const response = await ApiClient.get<CommentsResponse>(`/posts/${postId}/comments`);
      
      // Update post's comment count
      const post = this.postCache.get(postId);
      if (post) {
        post.commentCount = response.comments.length;
        this.postCache.set(postId, post);
      }
      
      return response.comments;
    } catch (error) {
      console.error(`Error fetching comments for post ${postId}:`, error);
      throw error;
    }
  }
  
  // Get top 5 users with most commented posts
  async getTopUsers(limit: number = 5): Promise<Array<{id: number, name: string, commentCount: number}>> {
    await this.refreshDataIfNeeded();
    
    // Convert Map to array for sorting
    const userCommentCounts = [...this.commentCountByUser.entries()]
      .map(([userId, commentCount]) => {
        const user = this.userCache.get(String(userId));
        return {
          id: Number(userId),
          name: user ? user.name : `User ${userId}`,
          commentCount
        };
      })
      .sort((a, b) => b.commentCount - a.commentCount)
      .slice(0, limit);
    
    return userCommentCounts;
  }
  
  // Get top posts by comment count
  async getPopularPosts(): Promise<Post[]> {
    await this.refreshDataIfNeeded();
    
    // Find maximum comment count
    let maxComments = 0;
    for (const post of this.postCache.values()) {
      if ((post.commentCount || 0) > maxComments) {
        maxComments = post.commentCount || 0;
      }
    }
    
    // Return all posts with the maximum comment count
    return [...this.postCache.values()]
      .filter(post => post.commentCount === maxComments)
      .sort((a, b) => b.commentCount! - a.commentCount!);
  }
  
  // Get latest 5 posts
  async getLatestPosts(limit: number = 5): Promise<Post[]> {
    await this.refreshDataIfNeeded();
    
    return [...this.postCache.values()]
      .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))
      .slice(0, limit);
  }
}

export default new DataService();
